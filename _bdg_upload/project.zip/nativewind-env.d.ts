/// <reference types="nativewind/types" />
